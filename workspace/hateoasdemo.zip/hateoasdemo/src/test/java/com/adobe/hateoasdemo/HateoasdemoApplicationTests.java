package com.adobe.hateoasdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HateoasdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
