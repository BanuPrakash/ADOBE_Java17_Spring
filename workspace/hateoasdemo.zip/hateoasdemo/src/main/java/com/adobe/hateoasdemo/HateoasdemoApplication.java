package com.adobe.hateoasdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HateoasdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(HateoasdemoApplication.class, args);
    }

}
