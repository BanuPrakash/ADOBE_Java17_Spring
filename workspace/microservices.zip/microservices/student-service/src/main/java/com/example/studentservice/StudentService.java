package com.example.studentservice;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {
    private final StudentDao studentDao;

    public Student saveStudent(Student student) {
        return studentDao.save(student);
    }

    public List<Student> getStudents() {
        return studentDao.findAll();
    }

    public List<Student> getStudentsBySchool(int id) {
        return studentDao.findAllBySchoolId(id);
    }
}
