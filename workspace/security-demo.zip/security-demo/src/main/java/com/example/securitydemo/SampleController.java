package com.example.securitydemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class SampleController {
    @GetMapping()
    public String greet() {
        return "Hello Spring Security!!!";
    }

    @GetMapping("products")
    public String getProducts() {
        return "Product List!!!";
    }

    @GetMapping("orders")
    public String getOrders() {
        return "Order List!!!";
    }
}
