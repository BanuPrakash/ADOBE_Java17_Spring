package com.example.kafkams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkamsApplicationTests {

    @Test
    void contextLoads() {
    }

}
