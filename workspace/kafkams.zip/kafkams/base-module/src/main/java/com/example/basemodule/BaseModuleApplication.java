package com.example.basemodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaseModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaseModuleApplication.class, args);
	}

}
