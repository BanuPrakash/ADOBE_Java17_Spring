package com.example.basemodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
