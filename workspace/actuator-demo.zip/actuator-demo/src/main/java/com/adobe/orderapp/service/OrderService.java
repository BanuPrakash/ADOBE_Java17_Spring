package com.adobe.orderapp.service;

import com.adobe.orderapp.dao.ProductDao;
import com.adobe.orderapp.entity.Product;
import io.micrometer.observation.annotation.Observed;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderService {
    private final ProductDao productDao;

    public List<Product> getProducts() {
        return productDao.findAll();
    }

    public Product addProduct(Product p) {
        return productDao.save(p);
    }

    @Transactional
    public Product updateProduct(int id, double price) {
        productDao.updateProduct(id, price);
        return productDao.findById(id).get();
    }

    public List<Product> getByRange(double low, double high) {
        return productDao.getByRange(low, high);
    }

    @Observed(name="products.load-by-id", contextualName = "products.findById")
    public Product getProductById(int id) throws EntityNotFoundException{
        Optional<Product> opt = productDao.findById(id);
        if(opt.isPresent()) {
            return opt.get();
        } else {
            throw new EntityNotFoundException("Product with id " + id + " not present");
        }
    }

}
