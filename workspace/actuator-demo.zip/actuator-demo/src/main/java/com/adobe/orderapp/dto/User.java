package com.adobe.orderapp.dto;

public record User(int id, String name, String email) {
}
