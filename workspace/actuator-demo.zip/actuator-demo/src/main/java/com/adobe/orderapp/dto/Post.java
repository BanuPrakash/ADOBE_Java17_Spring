package com.adobe.orderapp.dto;

public record   Post(int id, String title, String body, int userId) {
}
