package com.adobe.orderapp.service;

import com.adobe.orderapp.dao.UserDao;
import com.adobe.orderapp.dto.JwtResponse;
import com.adobe.orderapp.dto.SignInRequest;
import com.adobe.orderapp.dto.SignUpRequest;
import com.adobe.orderapp.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final UserDao userDao;
    private PasswordEncoder passwordEncoder;

    private JwtService jwtService;

    private  final AuthenticationManager authenticationManager;

    public JwtResponse register(SignUpRequest request) {
        var user = User.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .role(request.getRole()).build();
        userDao.save(user);

        var jwt = jwtService.generateToken(user);
        return new JwtResponse(jwt);
    }

    public JwtResponse login(SignInRequest request) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        var user = userDao.findByEmail(request.getEmail()).orElseThrow(() -> new IllegalArgumentException("invalid email/passwrod"));
        var jwt = jwtService.generateToken(user);
        return new JwtResponse(jwt);
    }
}
