package com.adobe.orderapp.entity;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
