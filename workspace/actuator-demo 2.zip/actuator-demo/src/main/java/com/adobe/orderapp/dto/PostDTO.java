package com.adobe.orderapp.dto;

public record PostDTO(String title, String user) {}
