package com.adobe.orderapp.api;

import com.adobe.orderapp.dto.JwtResponse;
import com.adobe.orderapp.dto.SignInRequest;
import com.adobe.orderapp.dto.SignUpRequest;
import com.adobe.orderapp.service.AuthenticationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthenticationController {
    private final AuthenticationService authenticationService;

    @PostMapping("/register")
    public JwtResponse register(@RequestBody SignUpRequest request) {
        return authenticationService.register(request);
    }

    @PostMapping("/login")
    public JwtResponse login(@RequestBody SignInRequest request) {
        return authenticationService.login(request);
    }

}
