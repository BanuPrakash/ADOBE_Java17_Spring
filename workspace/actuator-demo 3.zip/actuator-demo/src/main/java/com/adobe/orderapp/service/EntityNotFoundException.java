package com.adobe.orderapp.service;

public class EntityNotFoundException extends  Exception{
    public EntityNotFoundException(String message) {
        super(message);
    }
}
