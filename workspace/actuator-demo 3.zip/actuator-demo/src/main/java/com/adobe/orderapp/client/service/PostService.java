package com.adobe.orderapp.client.service;

import com.adobe.orderapp.dto.Post;
import com.adobe.orderapp.dto.PostDTO;
import com.adobe.orderapp.dto.User;
import com.adobe.orderapp.entity.Product;
import com.adobe.orderapp.service.PostInterface;
import com.adobe.orderapp.service.UserInterface;
import lombok.RequiredArgsConstructor;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PostService {
    private final RestTemplate restTemplate;
    public List<PostDTO> getPosts()  {
        ResponseEntity<List<Post>> response =
                restTemplate.exchange("https://jsonplaceholder.typicode.com/posts",
                        HttpMethod.GET, null, new ParameterizedTypeReference<List<Post>>() {
                        });

        List<Post> postList = response.getBody();


        List<User> userList =  restTemplate.exchange("https://jsonplaceholder.typicode.com/users",
                        HttpMethod.GET, null, new ParameterizedTypeReference<List<User>>() {
                        }).getBody();

        return postList.stream().map(post -> {
            String username = userList.stream()
                    .filter(user -> user.id() == post.userId()).findFirst().get().name();
            return new PostDTO(post.title(), username);
        }).collect(Collectors.toList());

    }

}
